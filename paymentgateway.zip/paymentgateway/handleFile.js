let cardimageUrl = {
  Visa: 'https://seeklogo.com/images/V/visa-logo-6F4057663D-seeklogo.com.png',
  AMEX:
    'https://banner2.cleanpng.com/20180616/hyo/kisspng-american-express-credit-card-mastercard-visa-payme-american-express-one-5b24ade4c8f530.4653463115291304688231.jpg',
  Mastercard:
    'https://4.bp.blogspot.com/-1Bkg9N3IbAg/V4fMj-n0foI/AAAAAAAAnhw/ZXvrn7lqNWMQFBVc8fu8BqNnF6vUbgpsgCLcB/s330/MasterCard-logo-1990.png',
  Discover:
    'https://banner2.cleanpng.com/20180604/isf/kisspng-discover-card-credit-card-debit-card-discover-fina-5b15e0f67b0440.1435243715281605025039.jpg',
  Diners:
    'https://www.famouslogos.org/wp-content/uploads/2013/04/diners-club-logo.jpg',
  'Diners - Carte Blanche':
    'https://www.famouslogos.org/wp-content/uploads/2013/04/diners-club-logo.jpg',
  JCB:
    'https://banner2.cleanpng.com/20180421/pqe/kisspng-jcb-co-ltd-logo-payment-credit-card-card-vetor-5adb21e09d8eb0.1002474415243104966454.jpg',
  'Visa Electron':
    'https://toppng.com/uploads/preview/visa-electron-new-vector-logo-free-115740169109qubigvpiy.png',
};

let cardType = '';

function validateFormOnSubmit(paymentForm) {
  console.log(document.getElementById('card_number-error').innerHTML);
  let cardDetails = {
    cardNo: document.getElementById('card_number').value,
    ex_date: document.getElementById('ex_date').value,
    cvv: document.getElementById('cvv').value,
    img: cardimageUrl[cardType],
  };
  if (
    document.getElementById('ex_date-error').innerHTML != '' ||
    document.getElementById('cvv-error').innerHTML != '' ||
    document.getElementById('card_number-error').innerHTML != '' ||
    cardDetails.cardNo == '' ||
    cardDetails.ex_date == '' ||
    cardDetails.cvv == ''
  ) {
    document.getElementById('save-error').innerHTML =
      '* Please check the fields';
  } else {
    document.getElementById('save-error').innerHTML = '';
    document.getElementById('card_number').value = '';
    document.getElementById('ex_date').value = '';
    document.getElementById('cvv').value = '';
    let card_details = localStorage.getItem('cards-details');
    if (card_details) {
      card_details = JSON.parse(card_details);
      card_details.push(cardDetails);
      console.log(card_details);
      localStorage.setItem('cards-details', JSON.stringify(card_details));
    } else {
      localStorage.setItem('cards-details', JSON.stringify([cardDetails]));
    }
    listCards();
  }
}

function listCards() {
  let p = document.getElementById('list-cards');
  p.innerHTML = '';
  let card_details = localStorage.getItem('cards-details');

  if (card_details) {
    card_details = JSON.parse(card_details);
    for (let i = 0; i < card_details.length; i++) {
      let newList = document.createElement('li');
      let cardValue = card_details[i].cardNo;
      cardValue = cardValue.split(' ').join('');
      newList.setAttribute(
        'id',
        cardValue + card_details[i].ex_date + card_details[i].cvv
      );
      newList.classList.add('shadow');
      newList.innerHTML =
        '<span>' +
        '<img src=' +
        card_details[i].img +
        '  height=15px width= 30px></span> <span>' +
        card_details[i].cardNo +
        '</span> <span id=' +
        cardValue +
        card_details[i].ex_date +
        card_details[i].cvv +
        '_span ' +
        'onclick="deleteCardDetail(event)" class="material-icons delete_icon">delete</span>';
      //newList.innerHTML = card_details[i].cardNo;
      p.appendChild(newList);
    }
  }
}

function deleteCardDetail(ev) {
  let id = ev.currentTarget.id.split('_')[0];
  document.getElementById(id).remove();
  let cards = localStorage.getItem('cards-details');
  if (cards) {
    cards = JSON.parse(cards);
    let index = cards.findIndex(x => {
      console.log(x.cardNo.split(' ').join('') + x.ex_date + x.cvv);
      return id === x.cardNo.split(' ').join('') + x.ex_date + x.cvv;
    });
    if (index >= 0) {
      cards.splice(index, 1);
      localStorage.setItem('cards-details', JSON.stringify(cards));
    }
    console.log(cards);
  }
}

function checkCardSpace() {
  let card_number = document.getElementById('card_number');
  let cardValue = card_number.value;
  if (
    cardValue[cardValue.length - 1] >= '0' &&
    cardValue[cardValue.length - 1] <= '9'
  ) {
    cardValue = cardValue.split(' ').join('');
    cardValue = cardValue.split(/(.{4})/).filter(O => O);
    card_number.value = cardValue.join(' ');
  } else {
    cardValue = cardValue.slice(0, cardValue.length - 1);
    card_number.value = cardValue;
  }
  if (card_number.value.length > 18) {
    let ex_date = document.getElementById('ex_date');
    ex_date.focus();
    ex_date.select();
  }
}

function checkCardValidation() {
  let card_number = document.getElementById('card_number');
  if (card_number.value) {
    cardType = GetCardType(card_number.value);
    console.log(cardType);
    if (!cardimageUrl.hasOwnProperty(cardType)) {
      document.getElementById('card_number-error').innerHTML =
        '* Please check card number';
    } else {
      document.getElementById('card_number-error').innerHTML = '';
    }
  }
}

function checkMonth() {
  let ex_date = document.getElementById('ex_date');
  let ex_value = ex_date.value;
  if (
    ex_value[ex_value.length - 1] >= '0' &&
    ex_value[ex_value.length - 1] <= '9'
  ) {
    if (ex_value.length == 2) {
      ex_date.value = ex_value + '/';
    }
  } else {
    ex_value = ex_value.slice(0, ex_value.length - 1);
    ex_date.value = ex_value;
  }
  if (ex_date.value.length > 4) {
    let cvv = document.getElementById('cvv');
    cvv.focus();
    cvv.select();
  }
}

function checkMonthValidation() {
  let ex_date = document.getElementById('ex_date');
  let ex_value = ex_date.value.split('/');
  if (ex_value[0] >= '01' && ex_value[0] <= '12' && ex_value[1] >= '20') {
    console.log(ex_value);
    document.getElementById('ex_date-error').innerHTML = '';
  } else {
    document.getElementById('ex_date-error').innerHTML =
      '* Please check valid date';
  }
}

function checkCvv() {
  let cvv = document.getElementById('cvv');
  let cvv_value = cvv.value;
  if (
    cvv_value[cvv_value.length - 1] >= '0' &&
    cvv_value[cvv_value.length - 1] <= '9'
  ) {
    console.log(cvv_value);
  } else {
    cvv_value = cvv_value.slice(0, cvv_value.length - 1);
    cvv.value = cvv_value;
  }
}
function checkCvvValidation() {
  let cvv = document.getElementById('cvv');
  if (cvv.value.length === 3) {
    document.getElementById('cvv-error').innerHTML = '';
  } else {
    document.getElementById('cvv-error').innerHTML = '* CVV invalid';
  }
}

function GetCardType(number) {
  // visa
  var re = new RegExp('^4');
  if (number.match(re) != null) return 'Visa';

  // Mastercard
  // Updated for Mastercard 2017 BINs expansion
  if (
    /^(5[1-5][0-9]{14}|2(22[1-9][0-9]{12}|2[3-9][0-9]{13}|[3-6][0-9]{14}|7[0-1][0-9]{13}|720[0-9]{12}))$/.test(
      number
    )
  )
    return 'Mastercard';

  re = new RegExp('^(5018|5020|5038|6304|6759|6761|6763)[0-9]{8,15}$');
  if (number.match(re) != null) return 'Maestro Card';

  // AMEX
  re = new RegExp('^3[47]');
  if (number.match(re) != null) return 'AMEX';

  // Discover
  re = new RegExp(
    '^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)'
  );
  if (number.match(re) != null) return 'Discover';

  // Diners
  re = new RegExp('^36');
  if (number.match(re) != null) return 'Diners';

  // Diners - Carte Blanche
  re = new RegExp('^30[0-5]');
  if (number.match(re) != null) return 'Diners - Carte Blanche';

  // JCB
  re = new RegExp('^35(2[89]|[3-8][0-9])');
  if (number.match(re) != null) return 'JCB';

  // Visa Electron
  re = new RegExp('^(4026|417500|4508|4844|491(3|7))');
  if (number.match(re) != null) return 'Visa Electron';

  return '';
}

document.addEventListener('DOMContentLoaded', function(event) {
  listCards();
});

